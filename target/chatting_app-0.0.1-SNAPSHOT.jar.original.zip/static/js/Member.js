function member(_id, _name, _emailId){
	this.name = _name;
	this.emailId = _emailId;
	this.id = _id;
}